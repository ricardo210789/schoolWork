/* Classe errordesconegut0
* Versio 1.0
* Data 17/09/14
*/
public class errordesconegut0
{ 
   public static void main(String[] args) 
   	{ 
	   	System.out.println("Hola Mon");
      }
   }
}
