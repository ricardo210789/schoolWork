/* Classe ErrorDesconegut2
* Data 21/09/15
*/
public class ErrorDesconegut2 { 
   public static void main(String[] args) { 
	   System.out.println("Hola Mon");
   } 
}
