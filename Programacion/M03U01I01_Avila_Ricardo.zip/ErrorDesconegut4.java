/* Classe ErrorDesconegut4
* Data 21/09/15
*/
public class ErrorDesconegut4 { 
   public static void main(String[] args) { 
   	System.out.println("Hola Mon");
   } 
}
