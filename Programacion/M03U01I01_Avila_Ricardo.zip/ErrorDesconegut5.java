/* Classe ErrorDesconegut5
* Data 21/09/15
*/
public class ErrorDesconegut5 { 
   public static void main(String[] args) { 
   	System.out.println("Hola Mon");
   } 
}
