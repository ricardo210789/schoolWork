/* Classe ErrorDesconegut3
* Data 21/09/15
*/
public class ErrorDesconegut3 { 
   public static void main(String[] args) { 
	   System.out.println("Hola Mon");
   } 
}
