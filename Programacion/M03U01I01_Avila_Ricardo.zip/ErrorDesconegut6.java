/* Classe ErrorDesconegut6
* Data 21/09/15
*/
public class ErrorDesconegut6 { 
   public static void main(String[] args) { 
	   System.out.println("Hola Mon");
   } 
}
