// classe Assignacio
public class Assignacio { 

	public static void main(String[] args) {

		int num1 = 4;

		double num2;	

		int resultat;		



		resultat = num1 + num2 + num3;

		System.out.println(resultat);

	}

}
