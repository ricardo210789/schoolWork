public class DivCero2{
	public static void main(String[] args){
		double num1, num2;
		num1 = 3.7;
		num2 = 0;

		System.out.println(num1 / num2);
			
	} 
}
