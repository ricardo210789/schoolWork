public class DivCero1{
	public static void main(String[] args){
		int num1, num2;
		num1 = 16;
		num2 = 0;

		System.out.println(num1 / num2);
			
	} 
}
