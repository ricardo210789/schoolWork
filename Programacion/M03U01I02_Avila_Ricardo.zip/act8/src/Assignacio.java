class Assignacio { 
	public static void main(String[] args) { 

		int num1 = 4, num2 = 2, num3 = 5, resultat;

		resultat = num1 + num2 + num3; 

		System.out.println(resultat);

	}   

}
