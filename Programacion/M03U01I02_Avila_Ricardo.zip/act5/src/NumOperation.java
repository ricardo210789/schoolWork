public class NumOperation{
	public static void main(String[] args){
		int num1, num2;
		double num3, num4; 

		num1 = 10;
		num2 = 3;
		num3 = 3.7;
		num4 = 1.2;

		System.out.println(num1 + " + " + num2 + " = " + (num1 + num2));
		System.out.println(num1 + " - " + num2 + " = " + (num1 - num2));
		System.out.println(num1 + " * " + num2 + " = " + (num1 * num2));
		System.out.println(num1 + " / " + num2 + " = " + (num1 / num2));
		System.out.println(num1 + " % " + num2 + " = " + (num1 % num2));
			
		System.out.println();

		System.out.println(num3 + " + " + num4 + " = " + (num3 + num4));
		System.out.println(num3 + " - " + num4 + " = " + (num3 - num4));
		System.out.println(num3 + " * " + num4 + " = " + (num3 * num4));
		System.out.println(num3 + " / " + num4 + " = " + (num3 / num4));
		System.out.println(num3 + " % " + num4 + " = " + (num3 % num4));


	} 
}
